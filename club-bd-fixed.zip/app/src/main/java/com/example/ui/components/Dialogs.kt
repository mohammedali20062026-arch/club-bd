package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTournamentDialog(
    onDismiss: () -> Unit,
    onCreate: (
        title: String,
        category: String,
        map: String,
        scheduleDisplay: String,
        entryFee: String,
        prizePool: String,
        totalSlots: Int,
        rules: String,
        roomId: String,
        roomPassword: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("SQUAD") }
    var selectedMap by remember { mutableStateOf("Bermuda") }
    var scheduleDisplay by remember { mutableStateOf("Tonight, 08:30 PM") }
    var entryFee by remember { mutableStateOf("FREE") }
    var prizePool by remember { mutableStateOf("৳2,500 BDT") }
    var totalSlots by remember { mutableStateOf("12") }
    var roomId by remember { mutableStateOf("") }
    var roomPassword by remember { mutableStateOf("") }
    var rules by remember { mutableStateOf("1. Mobile only, no PC/emulator.\n2. Gun skin attributes: OFF.\n3. Be in room 10 mins before start.\n4. Teaming up will result in ban.") }

    val categories = listOf("SOLO", "DUO", "SQUAD", "CLASH_SQUAD")
    val maps = listOf("Bermuda", "Purgatory", "Kalahari", "Alpine", "Nexterra")
    val quickTimes = listOf("Tonight, 08:30 PM", "Tonight, 10:00 PM", "Tomorrow, 04:00 PM", "Tomorrow, 09:00 PM")
    val quickPrizes = listOf("৳1,000 BDT", "৳2,500 BDT", "৳5,000 BDT", "৳10,000 BDT")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, ElectricBlue, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CREATE TOURNAMENT",
                            color = ElectricBlue,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Host a Free Fire custom room cup",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(color = GamingCardBorder)

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tournament Title") },
                    placeholder = { Text("e.g. BD Free Fire Squad Cup S2") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tournament_title_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedLabelColor = ElectricBlue,
                        unfocusedLabelColor = TextSecondary,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                // Category (Mode) Selection
                Text(text = "Tournament Mode", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedCategory == cat
                        val catLabel = when (cat) {
                            "CLASH_SQUAD" -> "CS 4v4"
                            else -> cat.lowercase().replaceFirstChar { it.uppercase() }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ElectricBlue else GamingDarkSurfaceVariant)
                                .border(
                                    1.5.dp,
                                    if (isSelected) ElectricBlue else GamingCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    selectedCategory = cat
                                    if (cat == "SOLO") totalSlots = "48"
                                    if (cat == "DUO") totalSlots = "24"
                                    if (cat == "SQUAD") totalSlots = "12"
                                    if (cat == "CLASH_SQUAD") totalSlots = "8"
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = catLabel,
                                    color = if (isSelected) TextOnAccent else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                if (isSelected) {
                                    Text(
                                        text = "✓ SELECTED",
                                        color = TextOnAccent,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Map Selection
                Text(text = "Select Map", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    maps.take(3).forEach { m ->
                        val isSelected = selectedMap == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) DeepGamingBlue else GamingDarkSurfaceVariant)
                                .border(1.5.dp, if (isSelected) ElectricBlue else GamingCardBorder, RoundedCornerShape(8.dp))
                                .clickable { selectedMap = m }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(14.dp))
                                }
                                Text(
                                    text = m,
                                    color = if (isSelected) ElectricBlue else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    maps.drop(3).forEach { m ->
                        val isSelected = selectedMap == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) DeepGamingBlue else GamingDarkSurfaceVariant)
                                .border(1.5.dp, if (isSelected) ElectricBlue else GamingCardBorder, RoundedCornerShape(8.dp))
                                .clickable { selectedMap = m }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(14.dp))
                                }
                                Text(
                                    text = m,
                                    color = if (isSelected) ElectricBlue else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Schedule Date & Time
                OutlinedTextField(
                    value = scheduleDisplay,
                    onValueChange = { scheduleDisplay = it },
                    label = { Text("Match Date & Time") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )
                // Quick Time Presets
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(quickTimes) { qt ->
                        AssistChip(
                            onClick = { scheduleDisplay = qt },
                            label = { Text(qt, fontSize = 11.sp) },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = NeonCyan,
                                containerColor = GamingDarkSurfaceVariant
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GamingCardBorder)
                        )
                    }
                }

                // Prize Pool & Entry Fee Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = prizePool,
                        onValueChange = { prizePool = it },
                        label = { Text("Prize Pool") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EsportsGold,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = EsportsGold,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = entryFee,
                        onValueChange = { entryFee = it },
                        label = { Text("Entry Fee") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricBlue,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                }

                // Quick Prize Chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(quickPrizes) { qp ->
                        AssistChip(
                            onClick = { prizePool = qp },
                            label = { Text(qp, fontSize = 11.sp) },
                            colors = AssistChipDefaults.assistChipColors(
                                labelColor = BooyahYellow,
                                containerColor = GamingDarkSurfaceVariant
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GamingCardBorder)
                        )
                    }
                }

                // Total Slots
                OutlinedTextField(
                    value = totalSlots,
                    onValueChange = { totalSlots = it },
                    label = { Text("Total Slots (Max Teams/Players)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                // Initial Room ID and Password (Optional)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = roomId,
                        onValueChange = { roomId = it },
                        label = { Text("Room ID (Optional)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricBlue,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = roomPassword,
                        onValueChange = { roomPassword = it },
                        label = { Text("Password") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricBlue,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                }

                // Rules
                OutlinedTextField(
                    value = rules,
                    onValueChange = { rules = it },
                    label = { Text("Match Rules") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                // Submit Button
                Button(
                    onClick = {
                        val finalTitle = title.ifBlank { "Free Fire $selectedCategory Cup" }
                        val slotsNum = totalSlots.toIntOrNull() ?: when (selectedCategory) {
                            "SOLO" -> 48
                            "DUO" -> 24
                            "SQUAD" -> 12
                            "CLASH_SQUAD" -> 8
                            else -> 12
                        }
                        onCreate(
                            finalTitle,
                            selectedCategory,
                            selectedMap,
                            scheduleDisplay.ifBlank { "Tonight, 08:30 PM" },
                            entryFee.ifBlank { "FREE" },
                            prizePool.ifBlank { "৳2,500 BDT" },
                            slotsNum,
                            rules.ifBlank { "1. Mobile only, no PC/emulator.\n2. Respect fair play.\n3. Be on time." },
                            roomId,
                            roomPassword
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_create_tournament_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = TextOnAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CREATE & PUBLISH TOURNAMENT", fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
            }
        }
    }
}

// Edit Tournament Dialog
@Composable
fun EditTournamentDialog(
    tournament: TournamentEntity,
    onDismiss: () -> Unit,
    onSave: (TournamentEntity) -> Unit
) {
    var title by remember { mutableStateOf(tournament.title) }
    var scheduleDisplay by remember { mutableStateOf(tournament.scheduleDisplay) }
    var map by remember { mutableStateOf(tournament.map) }
    var prizePool by remember { mutableStateOf(tournament.prizePool) }
    var entryFee by remember { mutableStateOf(tournament.entryFee) }
    var totalSlots by remember { mutableStateOf(tournament.totalSlots.toString()) }
    var rules by remember { mutableStateOf(tournament.rules) }

    val maps = listOf("Bermuda", "Purgatory", "Kalahari", "Alpine", "Nexterra")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, GamingCardBorder, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EDIT TOURNAMENT",
                        color = ElectricBlue,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = scheduleDisplay,
                    onValueChange = { scheduleDisplay = it },
                    label = { Text("Date & Time Schedule") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Text(text = "Map", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    maps.take(3).forEach { m ->
                        val isSelected = map == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) DeepGamingBlue else GamingDarkSurfaceVariant)
                                .border(1.dp, if (isSelected) ElectricBlue else GamingCardBorder, RoundedCornerShape(8.dp))
                                .clickable { map = m }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = m, color = if (isSelected) ElectricBlue else TextPrimary, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = prizePool,
                        onValueChange = { prizePool = it },
                        label = { Text("Prize Pool") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EsportsGold,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = EsportsGold,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = entryFee,
                        onValueChange = { entryFee = it },
                        label = { Text("Entry Fee") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricBlue,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                }

                OutlinedTextField(
                    value = totalSlots,
                    onValueChange = { totalSlots = it },
                    label = { Text("Total Slots") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = rules,
                    onValueChange = { rules = it },
                    label = { Text("Rules") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Button(
                    onClick = {
                        val updated = tournament.copy(
                            title = title.trim(),
                            scheduleDisplay = scheduleDisplay.trim(),
                            map = map,
                            prizePool = prizePool.trim(),
                            entryFee = entryFee.trim(),
                            totalSlots = totalSlots.toIntOrNull() ?: tournament.totalSlots,
                            rules = rules.trim()
                        )
                        onSave(updated)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = TextOnAccent),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("SAVE CHANGES", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Join Tournament ("I Joined" Dialog)
@Composable
fun JoinTournamentDialog(
    tournament: TournamentEntity,
    preferredSlot: Int? = null,
    onDismiss: () -> Unit,
    onJoin: (playerName: String, playerUid: String, teamName: String, slotNumber: Int?) -> Unit
) {
    var playerName by remember { mutableStateOf("") }
    var playerUid by remember { mutableStateOf("") }
    var teamName by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, VictoryGreen, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JOIN TOURNAMENT",
                            color = VictoryGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (preferredSlot != null) "Reserving Slot #$preferredSlot • ${tournament.title}" else tournament.title,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GamingDarkSurfaceVariant)
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Mode: ${tournament.category}", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Map: ${tournament.map}", color = TextPrimary, fontSize = 12.sp)
                        Text(text = tournament.entryFee, color = BooyahYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = playerName,
                    onValueChange = { playerName = it },
                    label = { Text("Free Fire In-Game Name (IGN)") },
                    placeholder = { Text("e.g. BD_Viper_99") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("join_player_name_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VictoryGreen,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = VictoryGreen,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = playerUid,
                    onValueChange = { playerUid = it },
                    label = { Text("Free Fire Player UID") },
                    placeholder = { Text("e.g. 192830491") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("join_player_uid_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VictoryGreen,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = VictoryGreen,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                if (tournament.category != "SOLO") {
                    OutlinedTextField(
                        value = teamName,
                        onValueChange = { teamName = it },
                        label = { Text("Team / Clan Name") },
                        placeholder = { Text("e.g. Bengal Tigers Esports") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("join_team_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VictoryGreen,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = VictoryGreen,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                }

                Button(
                    onClick = {
                        onJoin(playerName, playerUid, teamName, preferredSlot)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_join_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VictoryGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (preferredSlot != null) "I JOINED (CLAIM SLOT #$preferredSlot)" else "I JOINED / CONFIRM REGISTRATION",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

// Admin Add Player Manually Dialog
@Composable
fun AdminAddPlayerDialog(
    tournament: TournamentEntity,
    currentParticipantCount: Int,
    targetSlot: Int? = null,
    onDismiss: () -> Unit,
    onAddPlayer: (playerName: String, playerUid: String, teamName: String, slotNumber: Int) -> Unit
) {
    var playerName by remember { mutableStateOf("") }
    var playerUid by remember { mutableStateOf("") }
    var teamName by remember { mutableStateOf("") }
    var slotNumber by remember { mutableStateOf((targetSlot ?: (currentParticipantCount + 1)).toString()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, EsportsGold, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ADMIN: ADD PLAYER",
                            color = EsportsGold,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Manually insert player into slot roster",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = playerName,
                    onValueChange = { playerName = it },
                    label = { Text("Player In-Game Name (IGN)") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_player_name_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = playerUid,
                    onValueChange = { playerUid = it },
                    label = { Text("Free Fire UID / Phone") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_player_uid_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = teamName,
                    onValueChange = { teamName = it },
                    label = { Text("Team Name (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = slotNumber,
                    onValueChange = { slotNumber = it },
                    label = { Text("Slot Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Button(
                    onClick = {
                        val slot = slotNumber.toIntOrNull() ?: (targetSlot ?: (currentParticipantCount + 1))
                        onAddPlayer(playerName, playerUid, teamName, slot)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("admin_confirm_add_player_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EsportsGold,
                        contentColor = TextOnAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ADD TO TOURNAMENT", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Edit Participant Dialog
@Composable
fun EditPlayerDialog(
    participant: ParticipantEntity,
    onDismiss: () -> Unit,
    onSave: (ParticipantEntity) -> Unit
) {
    var playerName by remember { mutableStateOf(participant.playerName) }
    var playerUid by remember { mutableStateOf(participant.playerUid) }
    var teamName by remember { mutableStateOf(participant.teamName) }
    var slotNumber by remember { mutableStateOf(participant.slotNumber.toString()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, GamingCardBorder, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EDIT PLAYER DETAILS",
                        color = ElectricBlue,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = playerName,
                    onValueChange = { playerName = it },
                    label = { Text("Player IGN") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = playerUid,
                    onValueChange = { playerUid = it },
                    label = { Text("Player UID") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = teamName,
                    onValueChange = { teamName = it },
                    label = { Text("Team Name") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = slotNumber,
                    onValueChange = { slotNumber = it },
                    label = { Text("Slot Number") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Button(
                    onClick = {
                        val updated = participant.copy(
                            playerName = playerName.trim(),
                            playerUid = playerUid.trim(),
                            teamName = teamName.trim(),
                            slotNumber = slotNumber.toIntOrNull() ?: participant.slotNumber
                        )
                        onSave(updated)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = TextOnAccent),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("SAVE CHANGES", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Admin Room ID & Password Dialog
@Composable
fun AdminRoomCredentialsDialog(
    tournament: TournamentEntity,
    onDismiss: () -> Unit,
    onUpdate: (roomId: String, roomPassword: String, isRevealed: Boolean) -> Unit
) {
    var roomId by remember { mutableStateOf(tournament.roomId) }
    var roomPassword by remember { mutableStateOf(tournament.roomPassword) }
    var isRevealed by remember { mutableStateOf(tournament.isRoomRevealed) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, ElectricBlue, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ROOM ID & PASSWORD",
                            color = ElectricBlue,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Manage Free Fire custom match credentials",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = roomId,
                    onValueChange = { roomId = it },
                    label = { Text("Custom Room ID") },
                    placeholder = { Text("e.g. 8492019") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_room_id_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = roomPassword,
                    onValueChange = { roomPassword = it },
                    label = { Text("Room Password") },
                    placeholder = { Text("e.g. bd123") },
                    modifier = Modifier.fillMaxWidth().testTag("admin_room_password_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = ElectricBlue,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GamingDarkSurfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Reveal Room Details to Players",
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (isRevealed) "Visible to players on match screen" else "Hidden (displays 'Pending...')",
                            color = if (isRevealed) VictoryGreen else TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = isRevealed,
                        onCheckedChange = { isRevealed = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricBlue,
                            checkedTrackColor = DeepGamingBlue
                        )
                    )
                }

                Button(
                    onClick = {
                        onUpdate(roomId, roomPassword, isRevealed)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("admin_save_room_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = TextOnAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SAVE ROOM CREDENTIALS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Announce Winners Dialog
@Composable
fun AdminAnnounceWinnersDialog(
    tournament: TournamentEntity,
    onDismiss: () -> Unit,
    onAnnounce: (
        firstPlace: String,
        secondPlace: String,
        thirdPlace: String,
        mvp: String,
        firstKills: Int,
        firstPrize: String
    ) -> Unit
) {
    var firstPlace by remember { mutableStateOf("") }
    var secondPlace by remember { mutableStateOf("") }
    var thirdPlace by remember { mutableStateOf("") }
    var mvp by remember { mutableStateOf("") }
    var firstKills by remember { mutableStateOf("12") }
    var firstPrize by remember { mutableStateOf("৳1,500 BDT + Trophy") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.5.dp, BooyahYellow, RoundedCornerShape(20.dp)),
            color = GamingDarkSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ANNOUNCE WINNERS",
                            color = BooyahYellow,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Post official results & complete match",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                OutlinedTextField(
                    value = firstPlace,
                    onValueChange = { firstPlace = it },
                    label = { Text("🏆 1st Place (Booyah Champion)") },
                    placeholder = { Text("e.g. Team Apex / Player Name") },
                    modifier = Modifier.fillMaxWidth().testTag("winner_1st_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = secondPlace,
                    onValueChange = { secondPlace = it },
                    label = { Text("🥈 2nd Place (Runner-Up)") },
                    placeholder = { Text("e.g. Dhaka Warriors") },
                    modifier = Modifier.fillMaxWidth().testTag("winner_2nd_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = thirdPlace,
                    onValueChange = { thirdPlace = it },
                    label = { Text("🥉 3rd Place") },
                    placeholder = { Text("e.g. Bengal Tigers") },
                    modifier = Modifier.fillMaxWidth().testTag("winner_3rd_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = firstKills,
                        onValueChange = { firstKills = it },
                        label = { Text("Champion Kills") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BattleRed,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = BattleRed,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = mvp,
                        onValueChange = { mvp = it },
                        label = { Text("MVP Player") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BooyahYellow,
                            unfocusedBorderColor = GamingCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = BooyahYellow,
                            focusedContainerColor = GamingDarkSurfaceVariant,
                            unfocusedContainerColor = GamingDarkSurfaceVariant
                        )
                    )
                }

                OutlinedTextField(
                    value = firstPrize,
                    onValueChange = { firstPrize = it },
                    label = { Text("1st Place Prize Description") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EsportsGold,
                        unfocusedBorderColor = GamingCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = EsportsGold,
                        focusedContainerColor = GamingDarkSurfaceVariant,
                        unfocusedContainerColor = GamingDarkSurfaceVariant
                    )
                )

                Button(
                    onClick = {
                        val kills = firstKills.toIntOrNull() ?: 10
                        val p1 = firstPlace.ifBlank { "Champion Squad" }
                        val p2 = secondPlace.ifBlank { "Runner Up Squad" }
                        val p3 = thirdPlace.ifBlank { "3rd Place Squad" }
                        val mvpName = mvp.ifBlank { p1 }
                        onAnnounce(p1, p2, p3, mvpName, kills, firstPrize)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_announce_winners_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EsportsGold,
                        contentColor = TextOnAccent
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PUBLISH RESULTS & WINNERS", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
