package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.data.entity.TournamentResultEntity
import com.example.ui.theme.*

@Composable
fun TournamentDetailScreen(
    tournament: TournamentEntity,
    participants: List<ParticipantEntity>,
    results: List<TournamentResultEntity>,
    onBack: () -> Unit,
    onJoinClick: (slot: Int?) -> Unit,
    onLeaveClick: () -> Unit,
    onAdminAddPlayerClick: (slot: Int?) -> Unit,
    onAdminEditPlayerClick: (ParticipantEntity) -> Unit,
    onAdminRoomClick: () -> Unit,
    onAdminEditTournamentClick: () -> Unit,
    onAdminAnnounceWinnersClick: () -> Unit,
    onRemoveParticipant: (ParticipantEntity) -> Unit,
    onStatusChange: (String) -> Unit,
    onDeleteTournament: () -> Unit,
    onCopy: (label: String, text: String) -> Unit
) {
    var showAdminMenu by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Overview & Room, 1: Roster & Slots, 2: Winners / Results

    val categoryColor = when (tournament.category.uppercase()) {
        "SOLO" -> ElectricBlue
        "DUO" -> NeonCyan
        "SQUAD" -> EsportsGold
        "CLASH_SQUAD" -> BattleRed
        else -> ElectricBlue
    }

    val participantBySlot = remember(participants) {
        participants.associateBy { it.slotNumber }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingDarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // Top Navigation Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(GamingDarkSurfaceVariant)
                        .testTag("detail_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ElectricBlue)
                }

                Text(
                    text = "MATCH DETAILS",
                    color = TextPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )

                // Admin Dropdown Menu
                Box {
                    IconButton(
                        onClick = { showAdminMenu = true },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(GamingDarkSurfaceVariant)
                            .testTag("detail_admin_menu_button")
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin Menu", tint = EsportsGold)
                    }

                    DropdownMenu(
                        expanded = showAdminMenu,
                        onDismissRequest = { showAdminMenu = false },
                        modifier = Modifier.background(GamingDarkSurface)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit Tournament Details", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = NeonCyan) },
                            onClick = {
                                showAdminMenu = false
                                onAdminEditTournamentClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Set Room ID & Password", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = ElectricBlue) },
                            onClick = {
                                showAdminMenu = false
                                onAdminRoomClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Add Player to Roster", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.PersonAdd, contentDescription = null, tint = EsportsGold) },
                            onClick = {
                                showAdminMenu = false
                                onAdminAddPlayerClick(null)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Announce Winners & Results", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = BooyahYellow) },
                            onClick = {
                                showAdminMenu = false
                                onAdminAnnounceWinnersClick()
                            }
                        )
                        Divider(color = GamingCardBorder)
                        if (tournament.status != "ONGOING") {
                            DropdownMenuItem(
                                text = { Text("Mark as LIVE NOW", color = BattleRed) },
                                leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = BattleRed) },
                                onClick = {
                                    showAdminMenu = false
                                    onStatusChange("ONGOING")
                                }
                            )
                        }
                        if (tournament.status != "UPCOMING") {
                            DropdownMenuItem(
                                text = { Text("Mark as UPCOMING", color = NeonCyan) },
                                leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, tint = NeonCyan) },
                                onClick = {
                                    showAdminMenu = false
                                    onStatusChange("UPCOMING")
                                }
                            )
                        }
                        Divider(color = GamingCardBorder)
                        DropdownMenuItem(
                            text = { Text("Delete Tournament", color = BattleRed) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = BattleRed) },
                            onClick = {
                                showAdminMenu = false
                                onDeleteTournament()
                            }
                        )
                    }
                }
            }
        }

        // Tournament Card with Mode & Schedule
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, DeepGamingBlue, RoundedCornerShape(20.dp)),
                color = GamingDarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(GamingCardElevated, GamingDarkSurface)
                            )
                        )
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(categoryColor.copy(alpha = 0.2f))
                                .border(1.dp, categoryColor, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "MODE: ${tournament.category}",
                                color = categoryColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }

                        val statusColor = when (tournament.status) {
                            "ONGOING" -> BattleRed
                            "COMPLETED" -> VictoryGreen
                            else -> NeonCyan
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(statusColor.copy(alpha = 0.2f))
                                .border(1.dp, statusColor, RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (tournament.status == "ONGOING") "● LIVE NOW" else tournament.status,
                                color = statusColor,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = tournament.title,
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )

                    // Map & Schedule row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                            Text(text = "Map: ${tournament.map}", color = TextSecondary, fontSize = 13.sp)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = EsportsGold, modifier = Modifier.size(16.dp))
                            Text(text = tournament.scheduleDisplay, color = TextSecondary, fontSize = 13.sp)
                        }
                    }

                    Divider(color = GamingCardBorder)

                    // Prize Pool & Slots
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "PRIZE POOL", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = tournament.prizePool, color = BooyahYellow, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "ENTRY FEE", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = tournament.entryFee, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "SLOTS FILLED", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            val filled = participants.size
                            Text(
                                text = "$filled / ${tournament.totalSlots}",
                                color = if (filled >= tournament.totalSlots) BattleRed else VictoryGreen,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        // Room ID and Password Box
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(
                        1.5.dp,
                        if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) ElectricBlue else GamingCardBorder,
                        RoundedCornerShape(16.dp)
                    ),
                color = GamingDarkSurfaceVariant
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(DeepGamingBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.VpnKey,
                                    contentDescription = null,
                                    tint = ElectricBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Text(
                                text = "CUSTOM ROOM CREDENTIALS",
                                color = TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Edit room button
                        IconButton(
                            onClick = onAdminRoomClick,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(GamingDarkSurface)
                                .testTag("admin_edit_room_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Room", tint = EsportsGold, modifier = Modifier.size(16.dp))
                        }
                    }

                    if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Room ID
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GamingDarkSurface)
                                    .border(1.dp, GamingCardBorder, RoundedCornerShape(12.dp))
                                    .clickable { onCopy("Room ID", tournament.roomId) }
                                    .padding(12.dp)
                                    .testTag("copy_room_id_button")
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "ROOM ID", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = ElectricBlue, modifier = Modifier.size(14.dp))
                                    }
                                    Text(
                                        text = tournament.roomId,
                                        color = ElectricBlue,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            // Password
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GamingDarkSurface)
                                    .border(1.dp, GamingCardBorder, RoundedCornerShape(12.dp))
                                    .clickable { onCopy("Room Password", tournament.roomPassword) }
                                    .padding(12.dp)
                                    .testTag("copy_room_password_button")
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "PASSWORD", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = ElectricBlue, modifier = Modifier.size(14.dp))
                                    }
                                    Text(
                                        text = tournament.roomPassword,
                                        color = ElectricBlue,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }

                        Text(
                            text = "💡 Tap ID or Password to copy. Launch Free Fire > Custom Room > Join.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(GamingDarkSurface)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp))
                                Text(
                                    text = "Room ID & Password will unlock before match start",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Registration Banner: Joined status or "I Joined" button
        item {
            if (tournament.hasJoined) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, VictoryGreen, RoundedCornerShape(16.dp)),
                    color = GamingDarkSurface
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(VictoryGreen.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = VictoryGreen, modifier = Modifier.size(22.dp))
                                }
                                Column {
                                    Text(
                                        text = "YOU ARE REGISTERED (Slot #${tournament.joinedSlotNumber})",
                                        color = VictoryGreen,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "IGN: ${tournament.joinedPlayerName} • UID: ${tournament.joinedPlayerUid}",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            // Leave tournament button
                            OutlinedButton(
                                onClick = onLeaveClick,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BattleRed),
                                border = androidx.compose.foundation.BorderStroke(1.dp, BattleRed.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Leave", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                val slotsFull = participants.size >= tournament.totalSlots
                Button(
                    onClick = { onJoinClick(null) },
                    enabled = !slotsFull && tournament.status != "COMPLETED",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("join_tournament_action_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VictoryGreen,
                        contentColor = Color.White,
                        disabledContainerColor = GamingDarkSurfaceVariant,
                        disabledContentColor = TextMuted
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (slotsFull) "ALL SLOTS FULL" else "I JOINED / REGISTER FOR TOURNAMENT",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // Section Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(GamingDarkSurfaceVariant)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf(
                    "Overview & Rules",
                    "Slots Roster (${participants.size}/${tournament.totalSlots})",
                    "Results & Winners"
                )
                tabs.forEachIndexed { index, tabTitle ->
                    val isSelected = selectedTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricBlue else Color.Transparent)
                            .clickable { selectedTab = index }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tabTitle,
                            color = if (isSelected) TextOnAccent else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Overview & Rules
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, GamingCardBorder, RoundedCornerShape(16.dp)),
                        color = GamingDarkSurface
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "MATCH RULES & FORMAT",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                IconButton(onClick = onAdminEditTournamentClick, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Rules", tint = ElectricBlue, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(
                                text = tournament.rules,
                                color = TextSecondary,
                                fontSize = 13.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }

                item {
                    // Quick Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onAdminAddPlayerClick(null) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = EsportsGold),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EsportsGold)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Player", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onAdminAnnounceWinnersClick,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BooyahYellow),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BooyahYellow)
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Announce Winner", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            1 -> {
                // Interactive Roster with All Slots
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ALL SLOTS (1 to ${tournament.totalSlots})",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        TextButton(
                            onClick = { onAdminAddPlayerClick(null) },
                            colors = ButtonDefaults.textButtonColors(contentColor = EsportsGold)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Manually", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                // Render slots 1 to totalSlots
                val total = tournament.totalSlots
                items(total) { index ->
                    val slotNum = index + 1
                    val participant = participantBySlot[slotNum]

                    if (participant != null) {
                        // Occupied Slot
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    1.dp,
                                    if (participant.isDeviceUser) VictoryGreen else GamingCardBorder,
                                    RoundedCornerShape(12.dp)
                                ),
                            color = GamingDarkSurface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (participant.isDeviceUser) VictoryGreen else DeepGamingBlue),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "#$slotNum",
                                            color = if (participant.isDeviceUser) Color.White else ElectricBlue,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = participant.playerName,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            if (participant.isDeviceUser) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(VictoryGreen.copy(alpha = 0.2f))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text("YOU", color = VictoryGreen, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                                }
                                            }
                                            if (participant.addedByAdmin) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(EsportsGold.copy(alpha = 0.2f))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text("ADMIN", color = EsportsGold, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                                }
                                            }
                                        }

                                        Text(
                                            text = "UID: ${participant.playerUid} ${if (participant.teamName.isNotBlank()) "• ${participant.teamName}" else ""}",
                                            color = TextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onAdminEditPlayerClick(participant) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Player", tint = ElectricBlue, modifier = Modifier.size(15.dp))
                                    }

                                    IconButton(
                                        onClick = { onRemoveParticipant(participant) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = TextMuted, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    } else {
                        // Free / Open Slot
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, GamingCardBorder.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .clickable {
                                    if (!tournament.hasJoined) {
                                        onJoinClick(slotNum)
                                    } else {
                                        onAdminAddPlayerClick(slotNum)
                                    }
                                },
                            color = GamingDarkSurfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(GamingDarkSurface),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "#$slotNum",
                                            color = TextMuted,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Text(
                                        text = "Open Slot Available",
                                        color = TextSecondary,
                                        fontSize = 13.sp
                                    )
                                }

                                Text(
                                    text = if (!tournament.hasJoined) "+ Claim Slot" else "+ Add Player",
                                    color = if (!tournament.hasJoined) VictoryGreen else EsportsGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            2 -> {
                // Match Results & Winner Announcements
                item {
                    if (results.isEmpty()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, GamingCardBorder, RoundedCornerShape(16.dp)),
                            color = GamingDarkSurface
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = BooyahYellow, modifier = Modifier.size(40.dp))
                                Text(
                                    text = "Match Results Pending",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Results and Booyah winners will be announced once the match concludes.",
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center,
                                    fontSize = 12.sp
                                )
                                Button(
                                    onClick = onAdminAnnounceWinnersClick,
                                    colors = ButtonDefaults.buttonColors(containerColor = BooyahYellow),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Post Results as Admin", color = TextOnAccent, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        // Winner Announcement Podium
                        val champion = results.firstOrNull { it.rank == 1 }
                        if (champion != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(EsportsGold.copy(alpha = 0.25f), GamingDarkSurface)
                                        )
                                    )
                                    .border(1.5.dp, EsportsGold, RoundedCornerShape(18.dp))
                                    .padding(18.dp)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = BooyahYellow,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Text(
                                        text = "👑 BOOYAH CHAMPION 👑",
                                        color = BooyahYellow,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = champion.playerName,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 22.sp
                                    )
                                    if (champion.teamName.isNotBlank()) {
                                        Text(text = champion.teamName, color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Text(text = "🔥 ${champion.kills} Kills", color = BattleRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = "💰 Prize: ${champion.prize}", color = VictoryGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "FINAL STANDINGS",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                items(results) { res ->
                    val rankColor = when (res.rank) {
                        1 -> BooyahYellow
                        2 -> Color(0xFFC0C0C0)
                        3 -> Color(0xFFCD7F32)
                        else -> TextSecondary
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, GamingCardBorder, RoundedCornerShape(12.dp)),
                        color = GamingDarkSurface
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(rankColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "#${res.rank}",
                                        color = rankColor,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp
                                    )
                                }

                                Column {
                                    Text(text = res.playerName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        text = "${res.kills} Kills • ${res.prize}",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            if (res.isMvp) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BattleRed.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text("MVP", color = BattleRed, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
