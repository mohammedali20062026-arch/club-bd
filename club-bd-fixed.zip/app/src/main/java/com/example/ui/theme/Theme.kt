package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val ClubBDColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = TextOnAccent,
    primaryContainer = DeepGamingBlue,
    onPrimaryContainer = TextPrimary,
    secondary = NeonCyan,
    onSecondary = TextOnAccent,
    secondaryContainer = GamingDarkSurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = EsportsGold,
    onTertiary = TextOnAccent,
    background = GamingDarkBackground,
    onBackground = TextPrimary,
    surface = GamingDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = GamingDarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = GamingCardBorder,
    outlineVariant = GamingCardElevated,
    error = BattleRed,
    onError = TextPrimary
)

@Composable
fun ClubBDTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = ClubBDColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = GamingDarkBackground.toArgb()
                window.navigationBarColor = GamingDarkBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
