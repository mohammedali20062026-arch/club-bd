package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Esports Gaming Dark Palette
val GamingDarkBackground = Color(0xFF080D1A)
val GamingDarkSurface = Color(0xFF0F172A)
val GamingDarkSurfaceVariant = Color(0xFF162238)
val GamingCardElevated = Color(0xFF1E2D4A)
val GamingCardBorder = Color(0xFF26395C)

// Neon & Brand Colors
val ElectricBlue = Color(0xFF00E5FF)
val NeonCyan = Color(0xFF38BDF8)
val DeepGamingBlue = Color(0xFF0284C7)
val EsportsGold = Color(0xFFFFB703)
val BooyahYellow = Color(0xFFFFD166)
val BattleRed = Color(0xFFFF3366)
val VictoryGreen = Color(0xFF10B981)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnAccent = Color(0xFF050B14)
