package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.TournamentEntity
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun TournamentListScreen(
    tournaments: List<TournamentEntity>,
    selectedCategory: String,
    selectedStatus: String,
    searchQuery: String,
    onCategorySelected: (String) -> Unit,
    onStatusSelected: (String) -> Unit,
    onSearchChanged: (String) -> Unit,
    onTournamentClick: (Long) -> Unit,
    onCreateClick: () -> Unit
) {
    val categories = listOf(
        "ALL" to "All Modes",
        "SOLO" to "Solo 1v1",
        "DUO" to "Duo 2v2",
        "SQUAD" to "Squad 4v4",
        "CLASH_SQUAD" to "Clash Squad"
    )

    val statuses = listOf(
        "ALL" to "All Status",
        "UPCOMING" to "Upcoming",
        "ONGOING" to "Live Now",
        "COMPLETED" to "Completed"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingDarkBackground)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChanged,
            placeholder = { Text("Search by name, map (Bermuda, Kalahari...)", color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = ElectricBlue) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChanged("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("tournament_search_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricBlue,
                unfocusedBorderColor = GamingCardBorder,
                focusedContainerColor = GamingDarkSurface,
                unfocusedContainerColor = GamingDarkSurface,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            singleLine = true
        )

        // Categories Horizontal Pills
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { (code, label) ->
                val isSelected = selectedCategory.equals(code, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) ElectricBlue else GamingDarkSurface)
                        .border(
                            1.dp,
                            if (isSelected) ElectricBlue else GamingCardBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onCategorySelected(code) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("filter_cat_$code"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) TextOnAccent else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Status Tabs Row
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(statuses) { (code, label) ->
                val isSelected = selectedStatus.equals(code, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) DeepGamingBlue else Color.Transparent)
                        .clickable { onStatusSelected(code) }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("filter_status_$code")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) NeonCyan else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Divider(
            color = GamingCardBorder.copy(alpha = 0.5f),
            modifier = Modifier.padding(top = 8.dp)
        )

        // Tournaments List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
        ) {
            if (tournaments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(54.dp)
                            )
                            Text(
                                text = "No tournaments found",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Try changing category or create a new match",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = onCreateClick,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Create Tournament", color = TextOnAccent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(tournaments, key = { it.id }) { tourney ->
                    TournamentCard(
                        tournament = tourney,
                        onClick = { onTournamentClick(tourney.id) }
                    )
                }
            }
        }
    }
}
