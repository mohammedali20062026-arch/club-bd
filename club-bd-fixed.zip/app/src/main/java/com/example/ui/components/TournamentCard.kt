package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.TournamentEntity
import com.example.ui.theme.*

@Composable
fun TournamentCard(
    tournament: TournamentEntity,
    participantCount: Int? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryColor = when (tournament.category.uppercase()) {
        "SOLO" -> ElectricBlue
        "DUO" -> NeonCyan
        "SQUAD" -> EsportsGold
        "CLASH_SQUAD" -> BattleRed
        else -> ElectricBlue
    }

    val categoryLabel = when (tournament.category.uppercase()) {
        "CLASH_SQUAD" -> "CLASH SQUAD 4v4"
        else -> tournament.category.uppercase()
    }

    val statusBg = when (tournament.status.uppercase()) {
        "ONGOING" -> BattleRed
        "COMPLETED" -> VictoryGreen
        else -> DeepGamingBlue
    }

    val statusText = when (tournament.status.uppercase()) {
        "ONGOING" -> "LIVE NOW"
        "COMPLETED" -> "FINISHED"
        else -> "UPCOMING"
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (tournament.hasJoined) ElectricBlue else GamingCardBorder,
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .testTag("tournament_card_${tournament.id}"),
        color = GamingDarkSurface,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GamingDarkSurfaceVariant.copy(alpha = 0.5f),
                            GamingDarkSurface
                        )
                    )
                )
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Category + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(categoryColor.copy(alpha = 0.15f))
                            .border(1.dp, categoryColor, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = categoryLabel,
                            color = categoryColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    if (tournament.hasJoined) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(VictoryGreen.copy(alpha = 0.2f))
                                .border(1.dp, VictoryGreen, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = VictoryGreen,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "JOINED",
                                    color = VictoryGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusBg.copy(alpha = 0.25f))
                        .border(1.dp, statusBg, RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (tournament.status.equals("ONGOING", ignoreCase = true)) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(BattleRed)
                            )
                        }
                        Text(
                            text = statusText,
                            color = if (tournament.status.equals("ONGOING", ignoreCase = true)) BattleRed else TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Title
            Text(
                text = tournament.title,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Info row: Map, Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = "Map",
                        tint = NeonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = tournament.map,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.AccessTime,
                        contentDescription = "Time",
                        tint = EsportsGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = tournament.scheduleDisplay,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Divider(color = GamingCardBorder.copy(alpha = 0.5f))

            // Bottom Metrics: Prize Pool, Entry Fee, Room State
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PRIZE POOL",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = BooyahYellow,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = tournament.prizePool,
                            color = BooyahYellow,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ENTRY",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = tournament.entryFee,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Room ID availability pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GamingDarkSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) Icons.Default.VpnKey else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) ElectricBlue else TextMuted,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) "Room Ready" else "Room Locked",
                            color = if (tournament.isRoomRevealed && tournament.roomId.isNotBlank()) ElectricBlue else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
