package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.entity.TournamentEntity
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    tournaments: List<TournamentEntity>,
    onTournamentClick: (Long) -> Unit,
    onCategoryClick: (String) -> Unit,
    onCreateClick: () -> Unit,
    onViewAllClick: () -> Unit
) {
    var selectedHomeMode by remember { mutableStateOf("ALL") }

    // Filter tournaments for home display based on selected mode
    val displayedTournaments = remember(tournaments, selectedHomeMode) {
        if (selectedHomeMode == "ALL") {
            tournaments
        } else {
            tournaments.filter { it.category.equals(selectedHomeMode, ignoreCase = true) }
        }
    }

    val liveTourneys = displayedTournaments.filter { it.status.equals("ONGOING", ignoreCase = true) }
    val upcomingTourneys = displayedTournaments.filter { it.status.equals("UPCOMING", ignoreCase = true) }
    val completedTourneys = displayedTournaments.filter { it.status.equals("COMPLETED", ignoreCase = true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingDarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        // 1. Hero Esports Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.5.dp, DeepGamingBlue, RoundedCornerShape(20.dp))
                    .testTag("hero_banner_container")
            ) {
                Image(
                    painter = painterResource(id = R.drawable.banner_esports),
                    contentDescription = "Esports Championship Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    GamingDarkBackground.copy(alpha = 0.88f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BattleRed)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "SEASON 2024 • TOURNAMENTS LIVE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "FREE FIRE BANGLADESH",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Create, join & manage custom rooms with cash prizes",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // 2. Interactive Tournament Categories Grid (Solo, Duo, Squad, Clash Squad)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOURNAMENT MODES",
                        color = TextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        letterSpacing = 0.8.sp
                    )

                    if (selectedHomeMode != "ALL") {
                        Text(
                            text = "Show All",
                            color = ElectricBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { selectedHomeMode = "ALL" }
                                .padding(4.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryItem(
                        title = "SOLO",
                        subtitle = "1 vs 47",
                        icon = Icons.Default.Person,
                        color = ElectricBlue,
                        isSelected = selectedHomeMode == "SOLO",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedHomeMode = if (selectedHomeMode == "SOLO") "ALL" else "SOLO"
                        }
                    )
                    CategoryItem(
                        title = "DUO",
                        subtitle = "2 vs 2",
                        icon = Icons.Default.Group,
                        color = NeonCyan,
                        isSelected = selectedHomeMode == "DUO",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedHomeMode = if (selectedHomeMode == "DUO") "ALL" else "DUO"
                        }
                    )
                    CategoryItem(
                        title = "SQUAD",
                        subtitle = "4 vs 4",
                        icon = Icons.Default.Groups,
                        color = EsportsGold,
                        isSelected = selectedHomeMode == "SQUAD",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedHomeMode = if (selectedHomeMode == "SQUAD") "ALL" else "SQUAD"
                        }
                    )
                    CategoryItem(
                        title = "CS 4v4",
                        subtitle = "Clash Squad",
                        icon = Icons.Default.FlashOn,
                        color = BattleRed,
                        isSelected = selectedHomeMode == "CLASH_SQUAD",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            selectedHomeMode = if (selectedHomeMode == "CLASH_SQUAD") "ALL" else "CLASH_SQUAD"
                        }
                    )
                }
            }
        }

        // 3. Quick Stats Bar
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, GamingCardBorder, RoundedCornerShape(16.dp)),
                color = GamingDarkSurface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatBox(label = "Total Tourneys", value = "${tournaments.size}")
                    VerticalDivider(modifier = Modifier.height(30.dp), color = GamingCardBorder)
                    StatBox(label = "Upcoming", value = "${tournaments.count { it.status == "UPCOMING" }}", color = NeonCyan)
                    VerticalDivider(modifier = Modifier.height(30.dp), color = GamingCardBorder)
                    StatBox(label = "Total Prize", value = "৳15K+", color = BooyahYellow)
                }
            }
        }

        // 4. Create Tournament Action Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.5.dp, DeepGamingBlue, RoundedCornerShape(16.dp))
                    .clickable { onCreateClick() }
                    .testTag("home_create_tournament_card"),
                color = GamingDarkSurfaceVariant
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ElectricBlue)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AddCircle,
                                contentDescription = null,
                                tint = TextOnAccent,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Host a Custom Match",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Set room ID, map, prize, rules & slots",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Button(
                        onClick = onCreateClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricBlue,
                            contentColor = TextOnAccent
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("CREATE", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // 5. Section Header for Featured Matches
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (selectedHomeMode == "ALL") "ALL MATCHES" else "$selectedHomeMode MATCHES",
                        color = TextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        letterSpacing = 0.8.sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(DeepGamingBlue)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${displayedTournaments.size}",
                            color = ElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Text(
                    text = "View in Tourneys Tab",
                    color = ElectricBlue,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable {
                            onCategoryClick(selectedHomeMode)
                            onViewAllClick()
                        }
                        .padding(vertical = 4.dp)
                )
            }
        }

        // 6. Tournaments List on Home Screen
        if (displayedTournaments.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(44.dp)
                        )
                        Text(
                            text = "No $selectedHomeMode matches yet",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                        Button(
                            onClick = onCreateClick,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Create $selectedHomeMode Tournament", color = TextOnAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Display all tournaments with Live first, then upcoming, then completed
            items(displayedTournaments, key = { it.id }) { tourney ->
                TournamentCard(
                    tournament = tourney,
                    onClick = { onTournamentClick(tourney.id) }
                )
            }
        }
    }
}

@Composable
private fun CategoryItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) color.copy(alpha = 0.2f) else GamingDarkSurface)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) color else GamingCardBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp)
            .testTag("home_category_$title"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) color else color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) TextOnAccent else color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                color = if (isSelected) color else TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = if (isSelected) "● ACTIVE" else subtitle,
                color = if (isSelected) color else TextSecondary,
                fontSize = 9.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun StatBox(
    label: String,
    value: String,
    color: Color = TextPrimary
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(text = label, color = TextSecondary, fontSize = 10.sp)
    }
}
