package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.TournamentDao
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.data.entity.TournamentResultEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TournamentEntity::class, ParticipantEntity::class, TournamentResultEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tournamentDao(): TournamentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "club_bd_tournaments.db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class AppDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.tournamentDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: TournamentDao) {
            if (dao.getTournamentCount() > 0) return

            // 1. Grand Squad Championship (Upcoming)
            val tourney1Id = dao.insertTournament(
                TournamentEntity(
                    title = "Club BD Squad Championship Season 5",
                    category = "SQUAD",
                    map = "Bermuda",
                    scheduleDisplay = "Tonight, 08:30 PM",
                    entryFee = "৳200 / Squad",
                    prizePool = "৳5,000 BDT",
                    totalSlots = 12, // 12 Squads = 48 players
                    status = "UPCOMING",
                    roomId = "8492019",
                    roomPassword = "bdff",
                    isRoomRevealed = true,
                    rules = "1. Mobile devices only, strictly no emulators or iPads.\n2. Gun attributes are OFF. Character skill is ON.\n3. Rooftop camping not allowed.\n4. Toxic behavior or abusing in all-chat results in disqualification.\n5. Custom room ID & Password shared 15 mins before match.",
                    hasJoined = false
                )
            )

            // Add some initial participants to Tourney 1
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney1Id,
                    slotNumber = 1,
                    playerName = "BD_Roxx7",
                    playerUid = "294810394",
                    teamName = "Team Bengal Tigers",
                    addedByAdmin = true
                )
            )
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney1Id,
                    slotNumber = 2,
                    playerName = "Viper_FF_BD",
                    playerUid = "839104821",
                    teamName = "Dhaka Assassins",
                    addedByAdmin = true
                )
            )
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney1Id,
                    slotNumber = 3,
                    playerName = "Shanto_Pro",
                    playerUid = "501928471",
                    teamName = "Sylhet Snipers",
                    addedByAdmin = true
                )
            )
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney1Id,
                    slotNumber = 4,
                    playerName = "Ninja_Tanvir",
                    playerUid = "920184712",
                    teamName = "Chittagong Kings",
                    addedByAdmin = true
                )
            )

            // 2. Solo King Bermuda (Ongoing)
            val tourney2Id = dao.insertTournament(
                TournamentEntity(
                    title = "Solo Rush King Cup",
                    category = "SOLO",
                    map = "Purgatory",
                    scheduleDisplay = "Today, 06:00 PM (LIVE)",
                    entryFee = "FREE",
                    prizePool = "৳1,500 BDT",
                    totalSlots = 48,
                    status = "ONGOING",
                    roomId = "4019283",
                    roomPassword = "rush",
                    isRoomRevealed = true,
                    rules = "1. Pure Solo showdown. Teaming up will lead to instant disqualification.\n2. Unlimited ammo: OFF.\n3. Grenade spamming allowed.\n4. Take screenshot of your rank & kills.",
                    hasJoined = true,
                    joinedPlayerName = "BD_Champion_X",
                    joinedPlayerUid = "109283471",
                    joinedSlotNumber = 7
                )
            )

            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney2Id,
                    slotNumber = 7,
                    playerName = "BD_Champion_X",
                    playerUid = "109283471",
                    isDeviceUser = true
                )
            )
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney2Id,
                    slotNumber = 1,
                    playerName = "Ghost_Reaper_BD",
                    playerUid = "491029481",
                    addedByAdmin = true
                )
            )
            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney2Id,
                    slotNumber = 2,
                    playerName = "Awm_God_Rahim",
                    playerUid = "301928495",
                    addedByAdmin = true
                )
            )

            // 3. Clash Squad 4v4 Showdown (Upcoming)
            val tourney3Id = dao.insertTournament(
                TournamentEntity(
                    title = "Clash Squad Hardcore 4v4",
                    category = "CLASH_SQUAD",
                    map = "Kalahari",
                    scheduleDisplay = "Tomorrow, 09:00 PM",
                    entryFee = "৳100 / Team",
                    prizePool = "৳3,000 BDT",
                    totalSlots = 8, // 8 teams bracket
                    status = "UPCOMING",
                    roomId = "Pending...",
                    roomPassword = "Will unlock at 08:45 PM",
                    isRoomRevealed = false,
                    rules = "1. Best of 7 rounds standard competitive CS.\n2. Double sniper, grenade spam strictly regulated.\n3. Default gun shop attributes.\n4. All 4 players must be present at lobby call.",
                    hasJoined = false
                )
            )

            dao.insertParticipant(
                ParticipantEntity(
                    tournamentId = tourney3Id,
                    slotNumber = 1,
                    playerName = "Captain_Faiz",
                    playerUid = "992019482",
                    teamName = "Red Wolves BD",
                    addedByAdmin = true
                )
            )

            // 4. Duo Masters Alpine (Completed with Announced Winners)
            val tourney4Id = dao.insertTournament(
                TournamentEntity(
                    title = "Duo Masters Alpine Invitational",
                    category = "DUO",
                    map = "Alpine",
                    scheduleDisplay = "Yesterday, 08:00 PM",
                    entryFee = "৳100 / Duo",
                    prizePool = "৳2,500 BDT",
                    totalSlots = 24,
                    status = "COMPLETED",
                    roomId = "3910291",
                    roomPassword = "done",
                    isRoomRevealed = true,
                    rules = "Completed match. Results verified by Club BD Esports admins.",
                    hasJoined = false,
                    winnerAnnounced = true
                )
            )

            // Add results for tournament 4
            dao.insertResults(
                listOf(
                    TournamentResultEntity(
                        tournamentId = tourney4Id,
                        rank = 1,
                        playerName = "Saif & Rakib (MVP)",
                        teamName = "Apex Predators BD",
                        kills = 14,
                        prize = "৳1,500 BDT + Trophy",
                        isMvp = true
                    ),
                    TournamentResultEntity(
                        tournamentId = tourney4Id,
                        rank = 2,
                        playerName = "Thunder & Strike",
                        teamName = "Dhaka Dynamos",
                        kills = 9,
                        prize = "৳700 BDT",
                        isMvp = false
                    ),
                    TournamentResultEntity(
                        tournamentId = tourney4Id,
                        rank = 3,
                        playerName = "Shadow & Raven",
                        teamName = "Night Raiders",
                        kills = 7,
                        prize = "৳300 BDT",
                        isMvp = false
                    )
                )
            )
        }
    }
}
