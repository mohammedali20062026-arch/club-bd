package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "participants")
data class ParticipantEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val slotNumber: Int,
    val playerName: String,
    val playerUid: String,
    val teamName: String = "",
    val isDeviceUser: Boolean = false,
    val addedByAdmin: Boolean = false,
    val kills: Int = 0
)
