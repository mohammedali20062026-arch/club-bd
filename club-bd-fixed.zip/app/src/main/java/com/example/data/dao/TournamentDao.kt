package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.data.entity.TournamentResultEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TournamentDao {
    @Query("SELECT * FROM tournaments ORDER BY id DESC")
    fun getAllTournaments(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments WHERE id = :id")
    fun getTournamentById(id: Long): Flow<TournamentEntity?>

    @Query("SELECT * FROM tournaments WHERE id = :id")
    suspend fun getTournamentByIdOnce(id: Long): TournamentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity): Long

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Query("DELETE FROM tournaments WHERE id = :id")
    suspend fun deleteTournament(id: Long)

    @Query("SELECT COUNT(*) FROM tournaments")
    suspend fun getTournamentCount(): Int

    // Participants
    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId ORDER BY slotNumber ASC")
    fun getParticipants(tournamentId: Long): Flow<List<ParticipantEntity>>

    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId ORDER BY slotNumber ASC")
    suspend fun getParticipantsOnce(tournamentId: Long): List<ParticipantEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParticipant(participant: ParticipantEntity): Long

    @Update
    suspend fun updateParticipant(participant: ParticipantEntity)

    @Query("DELETE FROM participants WHERE id = :id")
    suspend fun deleteParticipant(id: Long)

    @Query("DELETE FROM participants WHERE tournamentId = :tournamentId")
    suspend fun deleteParticipantsByTournament(tournamentId: Long)

    @Query("DELETE FROM participants WHERE tournamentId = :tournamentId AND isDeviceUser = 1")
    suspend fun deleteDeviceUserParticipant(tournamentId: Long)

    // Results
    @Query("SELECT * FROM tournament_results WHERE tournamentId = :tournamentId ORDER BY rank ASC")
    fun getResults(tournamentId: Long): Flow<List<TournamentResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(results: List<TournamentResultEntity>)

    @Query("DELETE FROM tournament_results WHERE tournamentId = :tournamentId")
    suspend fun deleteResultsByTournament(tournamentId: Long)
}
