package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournament_results")
data class TournamentResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tournamentId: Long,
    val rank: Int,
    val playerName: String,
    val teamName: String = "",
    val kills: Int,
    val prize: String,
    val isMvp: Boolean = false
)
