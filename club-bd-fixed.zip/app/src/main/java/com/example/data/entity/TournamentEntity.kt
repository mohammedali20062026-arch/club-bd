package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String, // SOLO, DUO, SQUAD, CLASH_SQUAD
    val map: String, // Bermuda, Purgatory, Kalahari, Alpine, Nexterra
    val scheduleDisplay: String,
    val entryFee: String,
    val prizePool: String,
    val totalSlots: Int,
    val status: String, // UPCOMING, ONGOING, COMPLETED
    val roomId: String = "",
    val roomPassword: String = "",
    val isRoomRevealed: Boolean = false,
    val rules: String = "1. Emulator players strictly forbidden.\n2. Hacks/scripts lead to permanent ban.\n3. Be in room 10 minutes before start time.\n4. Screen recording mandatory for dispute resolution.",
    val hasJoined: Boolean = false,
    val joinedPlayerName: String = "",
    val joinedPlayerUid: String = "",
    val joinedSlotNumber: Int = 0,
    val winnerAnnounced: Boolean = false
)
