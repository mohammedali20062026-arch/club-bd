package com.example.data.repository

import com.example.data.dao.TournamentDao
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.data.entity.TournamentResultEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class TournamentRepository(private val dao: TournamentDao) {

    val allTournaments: Flow<List<TournamentEntity>> = dao.getAllTournaments()

    fun getTournament(id: Long): Flow<TournamentEntity?> = dao.getTournamentById(id)

    fun getParticipants(tournamentId: Long): Flow<List<ParticipantEntity>> =
        dao.getParticipants(tournamentId)

    fun getResults(tournamentId: Long): Flow<List<TournamentResultEntity>> =
        dao.getResults(tournamentId)

    suspend fun createTournament(tournament: TournamentEntity): Long {
        return dao.insertTournament(tournament)
    }

    suspend fun updateTournament(tournament: TournamentEntity) {
        dao.updateTournament(tournament)
    }

    suspend fun deleteTournament(id: Long) {
        dao.deleteParticipantsByTournament(id)
        dao.deleteResultsByTournament(id)
        dao.deleteTournament(id)
    }

    suspend fun joinTournament(
        tournamentId: Long,
        playerName: String,
        playerUid: String,
        teamName: String = "",
        preferredSlot: Int? = null
    ): Boolean {
        val currentTourney = dao.getTournamentByIdOnce(tournamentId) ?: return false
        val participants = dao.getParticipantsOnce(tournamentId)

        if (participants.size >= currentTourney.totalSlots) {
            return false // Slots full
        }

        val takenSlots = participants.map { it.slotNumber }.toSet()
        val targetSlot = if (preferredSlot != null && !takenSlots.contains(preferredSlot) && preferredSlot in 1..currentTourney.totalSlots) {
            preferredSlot
        } else {
            var nextSlot = 1
            while (takenSlots.contains(nextSlot) && nextSlot <= currentTourney.totalSlots) {
                nextSlot++
            }
            if (nextSlot > currentTourney.totalSlots) return false
            nextSlot
        }

        val participant = ParticipantEntity(
            tournamentId = tournamentId,
            slotNumber = targetSlot,
            playerName = playerName,
            playerUid = playerUid,
            teamName = teamName,
            isDeviceUser = true,
            addedByAdmin = false
        )
        dao.insertParticipant(participant)

        dao.updateTournament(
            currentTourney.copy(
                hasJoined = true,
                joinedPlayerName = playerName,
                joinedPlayerUid = playerUid,
                joinedSlotNumber = targetSlot
            )
        )
        return true
    }

    suspend fun leaveTournament(tournamentId: Long): Boolean {
        val currentTourney = dao.getTournamentByIdOnce(tournamentId) ?: return false
        dao.deleteDeviceUserParticipant(tournamentId)
        dao.updateTournament(
            currentTourney.copy(
                hasJoined = false,
                joinedPlayerName = "",
                joinedPlayerUid = "",
                joinedSlotNumber = 0
            )
        )
        return true
    }

    suspend fun adminAddParticipant(
        tournamentId: Long,
        playerName: String,
        playerUid: String,
        teamName: String,
        slotNumber: Int
    ): Long {
        val participant = ParticipantEntity(
            tournamentId = tournamentId,
            slotNumber = slotNumber,
            playerName = playerName,
            playerUid = playerUid,
            teamName = teamName,
            isDeviceUser = false,
            addedByAdmin = true
        )
        return dao.insertParticipant(participant)
    }

    suspend fun updateParticipant(participant: ParticipantEntity) {
        dao.updateParticipant(participant)
    }

    suspend fun removeParticipant(participant: ParticipantEntity) {
        dao.deleteParticipant(participant.id)
        if (participant.isDeviceUser) {
            val tourney = dao.getTournamentByIdOnce(participant.tournamentId)
            if (tourney != null) {
                dao.updateTournament(
                    tourney.copy(
                        hasJoined = false,
                        joinedPlayerName = "",
                        joinedPlayerUid = "",
                        joinedSlotNumber = 0
                    )
                )
            }
        }
    }

    suspend fun updateRoomCredentials(
        tournamentId: Long,
        roomId: String,
        roomPassword: String,
        isRevealed: Boolean
    ) {
        val tourney = dao.getTournamentByIdOnce(tournamentId) ?: return
        dao.updateTournament(
            tourney.copy(
                roomId = roomId,
                roomPassword = roomPassword,
                isRoomRevealed = isRevealed
            )
        )
    }

    suspend fun updateTournamentStatus(tournamentId: Long, newStatus: String) {
        val tourney = dao.getTournamentByIdOnce(tournamentId) ?: return
        dao.updateTournament(tourney.copy(status = newStatus))
    }

    suspend fun saveWinnersAndComplete(
        tournamentId: Long,
        results: List<TournamentResultEntity>
    ) {
        val tourney = dao.getTournamentByIdOnce(tournamentId) ?: return
        dao.deleteResultsByTournament(tournamentId)
        dao.insertResults(results)
        dao.updateTournament(
            tourney.copy(
                status = "COMPLETED",
                winnerAnnounced = true
            )
        )
    }
}
