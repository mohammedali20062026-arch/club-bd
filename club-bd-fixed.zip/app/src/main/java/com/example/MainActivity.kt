package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.TournamentEntity
import com.example.ui.Screen
import com.example.ui.TournamentViewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.ClubBDTheme
import com.example.ui.theme.GamingDarkBackground
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: TournamentViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClubBDTheme {
                ClubBDApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ClubBDApp(viewModel: TournamentViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val allTournaments by viewModel.allTournaments.collectAsStateWithLifecycle()
    val filteredTournaments by viewModel.filteredTournaments.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedStatus by viewModel.selectedStatus.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val showCreate by viewModel.showCreateDialog.collectAsStateWithLifecycle()
    val editTournamentTarget by viewModel.showEditTournamentDialog.collectAsStateWithLifecycle()
    val joinTarget by viewModel.showJoinDialog.collectAsStateWithLifecycle()
    val adminAddPlayerTarget by viewModel.showAdminAddPlayerDialog.collectAsStateWithLifecycle()
    val editPlayerTarget by viewModel.showEditPlayerDialog.collectAsStateWithLifecycle()
    val adminRoomTarget by viewModel.showAdminRoomDialog.collectAsStateWithLifecycle()
    val adminAnnounceTarget by viewModel.showAdminAnnounceWinnersDialog.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Listen for snackbar toast messages
    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
        }
    }

    // Back handling for detail screen
    BackHandler(enabled = currentScreen is Screen.Detail) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingDarkBackground),
        containerColor = GamingDarkBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            ClubBDTopBar(
                currentScreen = currentScreen,
                onBack = if (currentScreen is Screen.Detail) {
                    { viewModel.navigateBack() }
                } else null,
                onCreateClick = { viewModel.showCreateDialog.value = true }
            )
        },
        bottomBar = {
            ClubBDBottomNav(
                currentScreen = currentScreen,
                onTabSelected = { screen -> viewModel.navigateTo(screen) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        tournaments = allTournaments,
                        onTournamentClick = { id -> viewModel.navigateTo(Screen.Detail(id)) },
                        onCategoryClick = { cat ->
                            viewModel.setCategoryFilter(cat)
                            viewModel.navigateTo(Screen.Tournaments)
                        },
                        onCreateClick = { viewModel.showCreateDialog.value = true },
                        onViewAllClick = {
                            viewModel.navigateTo(Screen.Tournaments)
                        }
                    )
                }

                is Screen.Tournaments -> {
                    TournamentListScreen(
                        tournaments = filteredTournaments,
                        selectedCategory = selectedCategory,
                        selectedStatus = selectedStatus,
                        searchQuery = searchQuery,
                        onCategorySelected = { viewModel.setCategoryFilter(it) },
                        onStatusSelected = { viewModel.setStatusFilter(it) },
                        onSearchChanged = { viewModel.setSearchQuery(it) },
                        onTournamentClick = { id -> viewModel.navigateTo(Screen.Detail(id)) },
                        onCreateClick = { viewModel.showCreateDialog.value = true }
                    )
                }

                is Screen.Schedule -> {
                    ScheduleScreen(
                        tournaments = allTournaments,
                        onTournamentClick = { id -> viewModel.navigateTo(Screen.Detail(id)) }
                    )
                }

                is Screen.Results -> {
                    ResultsScreen(
                        tournaments = allTournaments,
                        onTournamentClick = { id -> viewModel.navigateTo(Screen.Detail(id)) }
                    )
                }

                is Screen.Detail -> {
                    val tournamentFlow = remember(screen.tournamentId) {
                        viewModel.getTournamentDetails(screen.tournamentId)
                    }
                    val tournament by tournamentFlow.collectAsStateWithLifecycle(initialValue = null)

                    val participantsFlow = remember(screen.tournamentId) {
                        viewModel.getParticipants(screen.tournamentId)
                    }
                    val participants by participantsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

                    val resultsFlow = remember(screen.tournamentId) {
                        viewModel.getResults(screen.tournamentId)
                    }
                    val results by resultsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

                    if (tournament != null) {
                        TournamentDetailScreen(
                            tournament = tournament!!,
                            participants = participants,
                            results = results,
                            onBack = { viewModel.navigateBack() },
                            onJoinClick = { slot -> viewModel.showJoinDialog.value = Pair(tournament!!, slot) },
                            onLeaveClick = { viewModel.leaveTournament(screen.tournamentId) },
                            onAdminAddPlayerClick = { slot -> viewModel.showAdminAddPlayerDialog.value = Pair(tournament!!, slot) },
                            onAdminEditPlayerClick = { p -> viewModel.showEditPlayerDialog.value = p },
                            onAdminRoomClick = { viewModel.showAdminRoomDialog.value = tournament },
                            onAdminEditTournamentClick = { viewModel.showEditTournamentDialog.value = tournament },
                            onAdminAnnounceWinnersClick = { viewModel.showAdminAnnounceWinnersDialog.value = tournament },
                            onRemoveParticipant = { p -> viewModel.removeParticipant(p) },
                            onStatusChange = { status -> viewModel.updateStatus(screen.tournamentId, status) },
                            onDeleteTournament = { viewModel.deleteTournament(screen.tournamentId) },
                            onCopy = { label, text -> viewModel.copyToClipboard(label, text) }
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(GamingDarkBackground),
                            contentAlignment = androidx.compose.ui.Alignment.Center
                        ) {
                            CircularProgressIndicator(color = com.example.ui.theme.ElectricBlue)
                        }
                    }
                }
            }
        }
    }

    // Modal Dialogs
    if (showCreate) {
        CreateTournamentDialog(
            onDismiss = { viewModel.showCreateDialog.value = false },
            onCreate = { title, category, map, schedule, entryFee, prizePool, totalSlots, rules, roomId, roomPassword ->
                viewModel.createTournament(
                    title, category, map, schedule, entryFee, prizePool, totalSlots, rules, roomId, roomPassword
                )
            }
        )
    }

    editTournamentTarget?.let { tourney ->
        EditTournamentDialog(
            tournament = tourney,
            onDismiss = { viewModel.showEditTournamentDialog.value = null },
            onSave = { updated ->
                viewModel.updateTournament(updated)
            }
        )
    }

    joinTarget?.let { (tourney, slot) ->
        JoinTournamentDialog(
            tournament = tourney,
            preferredSlot = slot,
            onDismiss = { viewModel.showJoinDialog.value = null },
            onJoin = { name, uid, team, chosenSlot ->
                viewModel.joinTournament(tourney.id, name, uid, team, chosenSlot)
            }
        )
    }

    adminAddPlayerTarget?.let { (tourney, targetSlot) ->
        val participantsFlow = remember(tourney.id) { viewModel.getParticipants(tourney.id) }
        val currentParticipants by participantsFlow.collectAsStateWithLifecycle(initialValue = emptyList())

        AdminAddPlayerDialog(
            tournament = tourney,
            currentParticipantCount = currentParticipants.size,
            targetSlot = targetSlot,
            onDismiss = { viewModel.showAdminAddPlayerDialog.value = null },
            onAddPlayer = { name, uid, team, slot ->
                viewModel.adminAddPlayer(tourney.id, name, uid, team, slot)
            }
        )
    }

    editPlayerTarget?.let { participant ->
        EditPlayerDialog(
            participant = participant,
            onDismiss = { viewModel.showEditPlayerDialog.value = null },
            onSave = { updated ->
                viewModel.updateParticipant(updated)
            }
        )
    }

    adminRoomTarget?.let { tourney ->
        AdminRoomCredentialsDialog(
            tournament = tourney,
            onDismiss = { viewModel.showAdminRoomDialog.value = null },
            onUpdate = { roomId, password, isRevealed ->
                viewModel.updateRoomCredentials(tourney.id, roomId, password, isRevealed)
            }
        )
    }

    adminAnnounceTarget?.let { tourney ->
        AdminAnnounceWinnersDialog(
            tournament = tourney,
            onDismiss = { viewModel.showAdminAnnounceWinnersDialog.value = null },
            onAnnounce = { firstPlace, secondPlace, thirdPlace, mvp, kills, prize ->
                viewModel.announceWinners(tourney.id, firstPlace, secondPlace, thirdPlace, mvp, kills, prize)
            }
        )
    }
}

// Previews for Android Studio & AI Studio visual preview
@Preview(showBackground = true)
@Composable
fun ClubBDHomePreview() {
    ClubBDTheme {
        val sampleTournaments = listOf(
            TournamentEntity(
                id = 1,
                title = "Club BD Squad Championship Season 5",
                category = "SQUAD",
                map = "Bermuda",
                scheduleDisplay = "Tonight, 08:30 PM",
                entryFee = "৳200 / Squad",
                prizePool = "৳5,000 BDT",
                totalSlots = 12,
                status = "UPCOMING",
                roomId = "8492019",
                roomPassword = "bdff",
                isRoomRevealed = true
            ),
            TournamentEntity(
                id = 2,
                title = "Solo Rush King Cup",
                category = "SOLO",
                map = "Purgatory",
                scheduleDisplay = "Today, 06:00 PM (LIVE)",
                entryFee = "FREE",
                prizePool = "৳1,500 BDT",
                totalSlots = 48,
                status = "ONGOING",
                roomId = "4019283",
                roomPassword = "rush",
                isRoomRevealed = true
            )
        )
        HomeScreen(
            tournaments = sampleTournaments,
            onTournamentClick = {},
            onCategoryClick = {},
            onCreateClick = {},
            onViewAllClick = {}
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ClubBDTopBarPreview() {
    ClubBDTheme {
        ClubBDTopBar(
            currentScreen = Screen.Home,
            onBack = null,
            onCreateClick = {}
        )
    }
}
