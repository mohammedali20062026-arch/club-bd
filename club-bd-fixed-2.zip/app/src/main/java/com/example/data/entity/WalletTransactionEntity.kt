package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One wallet line.
 * type:   DEPOSIT, WITHDRAW, JOIN, REFUND
 * status: PENDING, ACCEPTED, REJECTED, JOINED, REFUNDED
 * amount: positive = money in, negative = money out
 */
@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String,
    val title: String,
    val amount: Double,
    val status: String,
    val timestamp: Long,
    val trxId: String,
    val method: String
)

/** Reads the first number out of strings like "৳200 / Squad" or "FREE" (-> 0). */
fun parseEntryFee(text: String): Int {
    val match = Regex("(\\d[\\d,]*)").find(text) ?: return 0
    return match.value.replace(",", "").toIntOrNull() ?: 0
}
