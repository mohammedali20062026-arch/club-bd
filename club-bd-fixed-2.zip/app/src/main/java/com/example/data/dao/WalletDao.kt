package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.data.entity.WalletTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC")
    fun getAll(): Flow<List<WalletTransactionEntity>>

    // Pending deposits are NOT counted. Pending withdrawals ARE counted (money is reserved).
    @Query(
        "SELECT COALESCE(SUM(amount), 0.0) FROM wallet_transactions " +
            "WHERE status IN ('ACCEPTED', 'JOINED', 'REFUNDED') " +
            "OR (type = 'WITHDRAW' AND status = 'PENDING')"
    )
    fun observeBalance(): Flow<Double>

    @Query(
        "SELECT COALESCE(SUM(amount), 0.0) FROM wallet_transactions " +
            "WHERE status IN ('ACCEPTED', 'JOINED', 'REFUNDED') " +
            "OR (type = 'WITHDRAW' AND status = 'PENDING')"
    )
    suspend fun getBalanceOnce(): Double

    @Insert
    suspend fun insert(tx: WalletTransactionEntity): Long

    @Query("UPDATE wallet_transactions SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)
}
