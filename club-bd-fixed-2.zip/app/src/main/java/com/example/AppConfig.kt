package com.example

object AppConfig {
    /** The bKash / Nagad / Rocket number where players send money for deposits. CHANGE THIS. */
    const val PAYMENT_NUMBER = "01791904658"
}
