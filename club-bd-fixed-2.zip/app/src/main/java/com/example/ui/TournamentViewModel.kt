package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.entity.ParticipantEntity
import com.example.data.entity.TournamentEntity
import com.example.data.entity.TournamentResultEntity
import com.example.data.entity.WalletTransactionEntity
import com.example.data.entity.parseEntryFee
import com.example.data.dao.WalletDao
import com.example.data.repository.TournamentRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Tournaments : Screen()
    object Schedule : Screen()
    object Results : Screen()
    object Wallet : Screen()
    data class Detail(val tournamentId: Long) : Screen()
}

class TournamentViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TournamentRepository
    private val walletDao: WalletDao
    private val clipboardManager =
        application.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = TournamentRepository(database.tournamentDao())
        walletDao = database.walletDao()
        viewModelScope.launch {
            AppDatabase.populateInitialData(database.tournamentDao())
        }
    }

    // Navigation State
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()
    private var previousScreen: Screen = Screen.Home

    // Filters
    private val _selectedCategory = MutableStateFlow("ALL") // ALL, SOLO, DUO, SQUAD, CLASH_SQUAD
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedStatus = MutableStateFlow("ALL") // ALL, UPCOMING, ONGOING, COMPLETED
    val selectedStatus: StateFlow<String> = _selectedStatus.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // UI Feedback
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    // Raw tournaments
    val allTournaments: StateFlow<List<TournamentEntity>> = repository.allTournaments
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered tournaments
    val filteredTournaments: StateFlow<List<TournamentEntity>> = combine(
        allTournaments,
        _selectedCategory,
        _selectedStatus,
        _searchQuery
    ) { tourneys, category, status, query ->
        tourneys.filter { item ->
            val matchCategory = category == "ALL" || item.category.equals(category, ignoreCase = true)
            val matchStatus = status == "ALL" || item.status.equals(status, ignoreCase = true)
            val matchQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.map.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true)
            matchCategory && matchStatus && matchQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selected Tournament detail flows
    private val _selectedTournamentId = MutableStateFlow<Long?>(null)
    val selectedTournamentId: StateFlow<Long?> = _selectedTournamentId.asStateFlow()

    fun getTournamentDetails(id: Long) = repository.getTournament(id)
    fun getParticipants(id: Long) = repository.getParticipants(id)
    fun getResults(id: Long) = repository.getResults(id)

    // Dialog States
    val showCreateDialog = MutableStateFlow(false)
    val showEditTournamentDialog = MutableStateFlow<TournamentEntity?>(null)
    val showJoinDialog = MutableStateFlow<Pair<TournamentEntity, Int?>?>(null)
    val showAdminAddPlayerDialog = MutableStateFlow<Pair<TournamentEntity, Int?>?>(null)
    val showEditPlayerDialog = MutableStateFlow<ParticipantEntity?>(null)
    val showAdminRoomDialog = MutableStateFlow<TournamentEntity?>(null)
    val showAdminAnnounceWinnersDialog = MutableStateFlow<TournamentEntity?>(null)

    // Navigation actions
    fun navigateTo(screen: Screen) {
        if (_currentScreen.value !is Screen.Detail) {
            previousScreen = _currentScreen.value
        }
        if (screen is Screen.Detail) {
            _selectedTournamentId.value = screen.tournamentId
        }
        _currentScreen.value = screen
    }

    fun navigateBack() {
        if (_currentScreen.value is Screen.Detail) {
            _currentScreen.value = previousScreen
        } else {
            _currentScreen.value = Screen.Home
        }
    }

    fun setCategoryFilter(category: String) {
        _selectedCategory.value = category
    }

    fun setStatusFilter(status: String) {
        _selectedStatus.value = status
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun showToast(msg: String) {
        viewModelScope.launch {
            _snackbarMessage.emit(msg)
        }
    }

    // Copy to clipboard
    fun copyToClipboard(label: String, text: String) {
        val clip = ClipData.newPlainText(label, text)
        clipboardManager.setPrimaryClip(clip)
        showToast("$label copied: $text")
    }

    // Create Tournament
    fun createTournament(
        title: String,
        category: String,
        map: String,
        scheduleDisplay: String,
        entryFee: String,
        prizePool: String,
        totalSlots: Int,
        rules: String,
        roomId: String,
        roomPassword: String
    ) {
        viewModelScope.launch {
            val newTourney = TournamentEntity(
                title = title.trim(),
                category = category,
                map = map,
                scheduleDisplay = scheduleDisplay.trim(),
                entryFee = if (entryFee.isBlank()) "FREE" else entryFee.trim(),
                prizePool = if (prizePool.isBlank()) "৳2,500 BDT" else prizePool.trim(),
                totalSlots = totalSlots,
                status = "UPCOMING",
                roomId = roomId.trim(),
                roomPassword = roomPassword.trim(),
                isRoomRevealed = roomId.isNotBlank(),
                rules = rules.ifBlank { "1. Mobile players only.\n2. Respect fair play.\n3. Be on time." }
            )
            val id = repository.createTournament(newTourney)
            showToast("Tournament \"$title\" created successfully! 🏆")
            showCreateDialog.value = false
            // Navigate to Home so the newly created tournament is visible right at the top of the Home Screen!
            navigateTo(Screen.Home)
        }
    }

    // Edit Tournament
    fun updateTournament(tournament: TournamentEntity) {
        viewModelScope.launch {
            repository.updateTournament(tournament)
            showToast("Tournament updated! ✍️")
            showEditTournamentDialog.value = null
        }
    }

    // Join Tournament ("I Joined" button)
    fun joinTournament(
        tournamentId: Long,
        playerName: String,
        playerUid: String,
        teamName: String,
        slotNumber: Int? = null
    ) {
        viewModelScope.launch {
            if (playerName.isBlank() || playerUid.isBlank()) {
                showToast("Please enter both In-Game Name and Free Fire UID")
                return@launch
            }
            val tourney = repository.getTournamentOnce(tournamentId)
            val fee = parseEntryFee(tourney?.entryFee ?: "")
            if (fee > 0) {
                val balance = walletDao.getBalanceOnce()
                if (balance < fee) {
                    showJoinDialog.value = null
                    showToast("Not enough balance. Entry fee ৳$fee, you have ৳${balance.toInt()}. Please add money.")
                    navigateTo(Screen.Wallet)
                    return@launch
                }
            }
            val success = repository.joinTournament(tournamentId, playerName.trim(), playerUid.trim(), teamName.trim(), slotNumber)
            if (success) {
                if (fee > 0) {
                    walletDao.insert(
                        WalletTransactionEntity(
                            type = "JOIN",
                            title = "${tourney?.title ?: "Tournament"} (Joined)",
                            amount = -fee.toDouble(),
                            status = "JOINED",
                            timestamp = System.currentTimeMillis(),
                            trxId = "",
                            method = ""
                        )
                    )
                }
                showToast("You have registered successfully! 🎮")
                showJoinDialog.value = null
            } else {
                showToast("Registration failed: Selected slot or tournament is full!")
            }
        }
    }

    // Leave Tournament
    fun leaveTournament(tournamentId: Long) {
        viewModelScope.launch {
            val tourney = repository.getTournamentOnce(tournamentId)
            val fee = parseEntryFee(tourney?.entryFee ?: "")
            val success = repository.leaveTournament(tournamentId)
            if (success) {
                if (fee > 0 && tourney?.status == "UPCOMING") {
                    walletDao.insert(
                        WalletTransactionEntity(
                            type = "REFUND",
                            title = "${tourney?.title ?: "Tournament"} (Refund)",
                            amount = fee.toDouble(),
                            status = "REFUNDED",
                            timestamp = System.currentTimeMillis(),
                            trxId = "",
                            method = ""
                        )
                    )
                    showToast("You have left the tournament. ৳$fee refunded to your wallet.")
                } else {
                    showToast("You have left the tournament. Slot is now free.")
                }
            }
        }
    }

    // Admin Add Player Manually
    fun adminAddPlayer(
        tournamentId: Long,
        playerName: String,
        playerUid: String,
        teamName: String,
        slotNumber: Int
    ) {
        viewModelScope.launch {
            if (playerName.isBlank()) {
                showToast("Please enter player name")
                return@launch
            }
            repository.adminAddParticipant(
                tournamentId = tournamentId,
                playerName = playerName.trim(),
                playerUid = if (playerUid.isBlank()) "Admin Assigned" else playerUid.trim(),
                teamName = teamName.trim(),
                slotNumber = slotNumber
            )
            showToast("Player $playerName added to Slot #$slotNumber")
            showAdminAddPlayerDialog.value = null
        }
    }

    // Admin Edit Existing Player
    fun updateParticipant(participant: ParticipantEntity) {
        viewModelScope.launch {
            repository.updateParticipant(participant)
            showToast("Player details updated")
            showEditPlayerDialog.value = null
        }
    }

    // Remove Participant
    fun removeParticipant(participant: ParticipantEntity) {
        viewModelScope.launch {
            repository.removeParticipant(participant)
            showToast("Removed ${participant.playerName} from tournament")
        }
    }

    // Update Room Credentials
    fun updateRoomCredentials(
        tournamentId: Long,
        roomId: String,
        roomPassword: String,
        isRevealed: Boolean
    ) {
        viewModelScope.launch {
            repository.updateRoomCredentials(tournamentId, roomId.trim(), roomPassword.trim(), isRevealed)
            showToast("Room ID & Password updated!")
            showAdminRoomDialog.value = null
        }
    }

    // Change Status
    fun updateStatus(tournamentId: Long, status: String) {
        viewModelScope.launch {
            repository.updateTournamentStatus(tournamentId, status)
            showToast("Tournament status set to $status")
        }
    }

    // Announce Winners
    fun announceWinners(
        tournamentId: Long,
        firstPlace: String,
        secondPlace: String,
        thirdPlace: String,
        mvp: String,
        firstKills: Int,
        firstPrize: String
    ) {
        viewModelScope.launch {
            val results = listOf(
                TournamentResultEntity(
                    tournamentId = tournamentId,
                    rank = 1,
                    playerName = firstPlace.trim(),
                    teamName = "Booyah Champion",
                    kills = firstKills,
                    prize = firstPrize.ifBlank { "Trophy + 1st Prize" },
                    isMvp = true
                ),
                TournamentResultEntity(
                    tournamentId = tournamentId,
                    rank = 2,
                    playerName = secondPlace.trim(),
                    teamName = "Runner Up",
                    kills = (firstKills * 0.7).toInt().coerceAtLeast(1),
                    prize = "2nd Place Cash",
                    isMvp = false
                ),
                TournamentResultEntity(
                    tournamentId = tournamentId,
                    rank = 3,
                    playerName = thirdPlace.trim(),
                    teamName = "3rd Place",
                    kills = (firstKills * 0.5).toInt().coerceAtLeast(1),
                    prize = "3rd Place Cash",
                    isMvp = false
                )
            )
            repository.saveWinnersAndComplete(tournamentId, results)
            showToast("Champions announced and tournament marked Completed! 🏆")
            showAdminAnnounceWinnersDialog.value = null
        }
    }

    // Delete Tournament
    fun deleteTournament(tournamentId: Long) {
        viewModelScope.launch {
            repository.deleteTournament(tournamentId)
            showToast("Tournament deleted")
            navigateBack()
        }
    }

    // ---------------- Wallet ----------------
    val walletBalance: StateFlow<Double> = walletDao.observeBalance()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    val walletTransactions: StateFlow<List<WalletTransactionEntity>> = walletDao.getAll()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun requestDeposit(amount: Int, method: String, trxId: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                showToast("Enter a valid amount")
                return@launch
            }
            if (trxId.isBlank()) {
                showToast("Enter the Transaction ID (TrxID)")
                return@launch
            }
            walletDao.insert(
                WalletTransactionEntity(
                    type = "DEPOSIT",
                    title = "Deposit $amount BDT via $method",
                    amount = amount.toDouble(),
                    status = "PENDING",
                    timestamp = System.currentTimeMillis(),
                    trxId = trxId.trim(),
                    method = method
                )
            )
            showToast("Deposit request sent. It will be added after admin approval.")
        }
    }

    fun requestWithdraw(amount: Int, number: String) {
        viewModelScope.launch {
            if (amount <= 0) {
                showToast("Enter a valid amount")
                return@launch
            }
            if (number.isBlank()) {
                showToast("Enter your bKash/Nagad number")
                return@launch
            }
            val balance = walletDao.getBalanceOnce()
            if (balance < amount) {
                showToast("Not enough balance")
                return@launch
            }
            walletDao.insert(
                WalletTransactionEntity(
                    type = "WITHDRAW",
                    title = "Withdraw $amount BDT to ${number.trim()}",
                    amount = -amount.toDouble(),
                    status = "PENDING",
                    timestamp = System.currentTimeMillis(),
                    trxId = "",
                    method = number.trim()
                )
            )
            showToast("Withdraw request sent.")
        }
    }

    // Admin actions on pending requests
    fun approveTransaction(tx: WalletTransactionEntity) {
        viewModelScope.launch {
            walletDao.setStatus(tx.id, "ACCEPTED")
            showToast("Approved")
        }
    }

    fun rejectTransaction(tx: WalletTransactionEntity) {
        viewModelScope.launch {
            walletDao.setStatus(tx.id, "REJECTED")
            showToast("Rejected")
        }
    }
}
