package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.example.AppConfig
import com.example.data.entity.WalletTransactionEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
    balance: Double,
    transactions: List<WalletTransactionEntity>,
    onDeposit: (amount: Int, method: String, trxId: String) -> Unit,
    onWithdraw: (amount: Int, number: String) -> Unit,
    onApprove: (WalletTransactionEntity) -> Unit,
    onReject: (WalletTransactionEntity) -> Unit
) {
    var showDeposit by remember { mutableStateOf(false) }
    var showWithdraw by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingDarkBackground),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(GamingCardElevated)
                    .border(1.dp, GamingCardBorder, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "AVAILABLE BALANCE",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "৳ " + String.format(Locale.US, "%.2f", balance),
                    color = ElectricBlue,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { showDeposit = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VictoryGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DEPOSIT", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { showWithdraw = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BattleRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WITHDRAW", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "Statements",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "No transactions yet. Tap DEPOSIT to add money.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            items(transactions, key = { it.id }) { tx ->
                TransactionRow(tx = tx, onApprove = onApprove, onReject = onReject)
            }
        }
    }

    if (showDeposit) {
        DepositDialog(
            onDismiss = { showDeposit = false },
            onSubmit = { amount, method, trx ->
                onDeposit(amount, method, trx)
                showDeposit = false
            }
        )
    }

    if (showWithdraw) {
        WithdrawDialog(
            balance = balance,
            onDismiss = { showWithdraw = false },
            onSubmit = { amount, number ->
                onWithdraw(amount, number)
                showWithdraw = false
            }
        )
    }
}

@Composable
private fun TransactionRow(
    tx: WalletTransactionEntity,
    onApprove: (WalletTransactionEntity) -> Unit,
    onReject: (WalletTransactionEntity) -> Unit
) {
    val isIn = tx.amount >= 0
    val amountColor = if (isIn) VictoryGreen else BattleRed
    val statusColor = when (tx.status) {
        "ACCEPTED", "REFUNDED" -> VictoryGreen
        "REJECTED" -> BattleRed
        "PENDING" -> EsportsGold
        else -> NeonCyan
    }
    val sign = if (isIn) "+" else "-"
    val amountText = sign + String.format(Locale.US, "%.2f", Math.abs(tx.amount))
    val dateText = remember(tx.timestamp) {
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date(tx.timestamp))
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(GamingDarkSurface)
            .border(1.dp, GamingCardBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(amountColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(text = dateText, color = TextMuted, fontSize = 12.sp)
                if (tx.trxId.isNotBlank()) {
                    Text(text = "TrxID: " + tx.trxId, color = TextSecondary, fontSize = 12.sp)
                }
                Text(
                    text = tx.status.lowercase().replaceFirstChar { it.uppercase() },
                    color = statusColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = amountText,
                color = amountColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (tx.status == "PENDING") {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onReject(tx) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Reject (admin)", color = BattleRed, fontSize = 12.sp)
                }
                Button(
                    onClick = { onApprove(tx) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VictoryGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Approve (admin)", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun DepositDialog(
    onDismiss: () -> Unit,
    onSubmit: (amount: Int, method: String, trxId: String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var trxId by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("bKash") }
    val methods = listOf("bKash", "Nagad", "Rocket")
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamingDarkSurface,
        title = { Text("Deposit Money", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "1. Send Money to this number:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = AppConfig.PAYMENT_NUMBER,
                        color = EsportsGold,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    OutlinedButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(AppConfig.PAYMENT_NUMBER))
                            copied = true
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(32.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (copied) "Copied \u2713" else "Copy", fontSize = 12.sp)
                    }
                }
                Text(
                    text = "2. Enter the amount and the Transaction ID (TrxID) you received.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    methods.forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m) }
                        )
                    }
                }
                OutlinedTextField(
                    value = amount,
                    onValueChange = { v -> amount = v.filter { it.isDigit() }.take(6) },
                    label = { Text("Amount (BDT)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = trxId,
                    onValueChange = { trxId = it.take(20) },
                    label = { Text("Transaction ID") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(amount.toIntOrNull() ?: 0, method, trxId) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = VictoryGreen,
                    contentColor = Color.White
                )
            ) { Text("Submit") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun WithdrawDialog(
    balance: Double,
    onDismiss: () -> Unit,
    onSubmit: (amount: Int, number: String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GamingDarkSurface,
        title = { Text("Withdraw Money", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Available: ৳ " + String.format(Locale.US, "%.2f", balance),
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { v -> amount = v.filter { it.isDigit() }.take(6) },
                    label = { Text("Amount (BDT)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = number,
                    onValueChange = { v -> number = v.filter { it.isDigit() }.take(11) },
                    label = { Text("bKash / Nagad number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(amount.toIntOrNull() ?: 0, number) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BattleRed,
                    contentColor = Color.White
                )
            ) { Text("Submit") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
